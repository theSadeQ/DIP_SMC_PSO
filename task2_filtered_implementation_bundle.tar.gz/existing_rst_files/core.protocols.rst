core.protocols module
===================

.. automodule:: src.core.protocols
   :members:
   :undoc-members:
   :show-inheritance: